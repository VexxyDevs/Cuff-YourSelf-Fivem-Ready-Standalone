resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

client_script 'client.lua'
title 'Cuff YourSelf Created By vexxy'
author 'vexxy'
description 'A script for cuffing and uncuffing yourself'
version '1.0.0'
