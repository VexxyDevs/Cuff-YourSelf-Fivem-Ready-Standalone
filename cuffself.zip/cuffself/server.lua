RegisterNetEvent("playCuffSound")
AddEventHandler("playCuffSound", function(cuff)
    local soundId = GetSoundId()

    if cuff then
        PlaySoundFrontend(soundId
