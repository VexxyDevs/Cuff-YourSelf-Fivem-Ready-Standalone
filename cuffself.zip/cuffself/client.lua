local cuffed = false
local cuffanim = "mp_arresting"

RegisterCommand('cuffself', function()
    if not cuffed then
        cuffed = true
        RequestAnimDict(cuffanim)

        while not HasAnimDictLoaded(cuffanim) do
            Citizen.Wait(100)
        end

        local playerPed = GetPlayerPed(-1)
        TaskPlayAnim(playerPed, cuffanim, "idle", 8.0, -8.0, -1, 49, 0, false, false, false)

        TriggerEvent('chat:addMessage', {
            color = {255, 0, 0}, -- Red color
            args = { 'My Body', 'I Have Been Cuffed But I Will Remain calm.' }
        })

        TriggerServerEvent("playCuffSound", true)
    else
        cuffed = false
        local playerPed = GetPlayerPed(-1)
        ClearPedTasks(playerPed)
        
        TriggerEvent('chat:addMessage', {
            color = {0, 255, 0}, -- Green color
            args = { 'My Body', 'I Have Been un-cuffed *SIGHS IN RELIEF* Thank God.' }
        })

        TriggerServerEvent("playCuffSound", false)
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if cuffed then
            DisableControlAction(0, 24, true) -- attack
            DisableControlAction(0, 21, true) -- sprint
        else
            EnableControlAction(0, 24, true) -- attack
            EnableControlAction(0, 21, true) -- sprint
        end
    end
end)
